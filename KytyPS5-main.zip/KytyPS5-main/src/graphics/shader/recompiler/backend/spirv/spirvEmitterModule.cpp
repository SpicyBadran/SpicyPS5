#include "graphics/shader/recompiler/backend/spirv/spirvEmitterInternal.h"

#include <algorithm>
#include <bit>

namespace Libs::Graphics::ShaderRecompiler::Spirv::Emitter {

uint32_t TypeVoid(EmitterState& state) {
	if (state.void_type == 0) {
		state.void_type = state.builder.Type(spv::OpTypeVoid);
	}
	return state.void_type;
}

uint32_t TypeBool(EmitterState& state) {
	if (state.bool_type == 0) {
		state.bool_type = state.builder.Type(spv::OpTypeBool);
	}
	return state.bool_type;
}

uint32_t TypeBoolVector(EmitterState& state, uint32_t components) {
	auto& type = state.bool_vector_types[components - 2u];
	if (type == 0) {
		type = state.builder.Type(spv::OpTypeVector, TypeBool(state), components);
	}
	return type;
}

uint32_t TypeU32(EmitterState& state) {
	if (state.u32_type == 0) {
		state.u32_type = state.builder.Type(spv::OpTypeInt, 32, 0);
	}
	return state.u32_type;
}

uint32_t TypeU64(EmitterState& state) {
	if (state.u64_type == 0) {
		state.builder.RequireCapability(spv::CapabilityInt64);
		state.u64_type = state.builder.Type(spv::OpTypeInt, 64, 0);
	}
	return state.u64_type;
}

uint32_t TypeU32Pair(EmitterState& state) {
	if (state.u32_pair_type == 0) {
		const auto element = TypeU32(state);
		state.u32_pair_type = state.builder.Type(spv::OpTypeStruct, element, element);
	}
	return state.u32_pair_type;
}

uint32_t TypeI32(EmitterState& state) {
	if (state.i32_type == 0) {
		state.i32_type = state.builder.Type(spv::OpTypeInt, 32, 1);
	}
	return state.i32_type;
}

uint32_t TypeI32Pair(EmitterState& state) {
	if (state.i32_pair_type == 0) {
		const auto element = TypeI32(state);
		state.i32_pair_type = state.builder.Type(spv::OpTypeStruct, element, element);
	}
	return state.i32_pair_type;
}

uint32_t TypeF32(EmitterState& state) {
	if (state.f32_type == 0) {
		state.f32_type = state.builder.Type(spv::OpTypeFloat, 32);
	}
	return state.f32_type;
}

uint32_t TypeF64(EmitterState& state) {
	if (state.f64_type == 0) {
		state.f64_type = state.builder.Type(spv::OpTypeFloat, 64);
	}
	return state.f64_type;
}

uint32_t TypeU32Vector(EmitterState& state, uint32_t components) {
	auto& type = state.u32_vector_types[components - 2u];
	if (type == 0) {
		type = state.builder.Type(spv::OpTypeVector, TypeU32(state), components);
	}
	return type;
}

uint32_t TypeU32Composite(EmitterState& state, uint32_t components) {
	EXIT_IF(components < 1u || components > 4u);
	if (components == 1u) return TypeU32(state);
	return components == 2u ? TypeU32Pair(state) : TypeU32Vector(state, components);
}

uint32_t TypeI32Vector(EmitterState& state, uint32_t components) {
	auto& type = state.i32_vector_types[components - 2u];
	if (type == 0) {
		type = state.builder.Type(spv::OpTypeVector, TypeI32(state), components);
	}
	return type;
}

uint32_t TypeF32Vector(EmitterState& state, uint32_t components) {
	auto& type = state.f32_vector_types[components - 2u];
	if (type == 0) {
		type = state.builder.Type(spv::OpTypeVector, TypeF32(state), components);
	}
	return type;
}

uint32_t TypePointer(EmitterState& state, spv::StorageClass storage_class, uint32_t pointee) {
	return state.builder.Type(spv::OpTypePointer, storage_class, pointee);
}

uint32_t TypeFunction(EmitterState& state) {
	if (state.function_type == 0) {
		state.function_type = state.builder.Type(spv::OpTypeFunction, TypeVoid(state));
	}
	return state.function_type;
}

uint32_t StorageBufferType(EmitterState& state, BufferDefinition& buffer, uint32_t bits = 32) {
	if (buffer.type == 0) {
		if (bits == 32u) {
			buffer.element_type = TypeU32(state);
		} else if (bits == 64u) {
			buffer.element_type = TypeU64(state);
		} else {
			buffer.element_type = state.builder.Type(spv::OpTypeInt, bits, 0);
		}
		const auto array = state.builder.DecoratedType(
		    spv::OpTypeRuntimeArray,
		    {{spv::OpDecorate, {spv::DecorationArrayStride, bits / 8u}}}, buffer.element_type);
		buffer.type = state.builder.DecoratedType(
		    spv::OpTypeStruct, {{spv::OpMemberDecorate, {0, spv::DecorationOffset, 0}},
		                        {spv::OpDecorate, {spv::DecorationBlock}}}, array);
	}
	return buffer.type;
}

uint32_t TypeStorageBufferElementPointer(EmitterState& state, uint32_t bits) {
	auto* buffer = &state.storage_buffers[2];
	if (bits == 8u) {
		buffer = &state.storage_buffers[0];
	} else if (bits == 16u) {
		buffer = &state.storage_buffers[1];
	} else if (bits == 64u) {
		buffer = &state.storage_buffers[3];
	}
	if (buffer->element_pointer_type == 0) {
		buffer->element_pointer_type =
		    TypePointer(state, spv::StorageClassStorageBuffer, buffer->element_type);
	}
	return buffer->element_pointer_type;
}

uint32_t TypePhysicalU32Pointer(EmitterState& state) {
	return TypePointer(state, spv::StorageClassPhysicalStorageBuffer, TypeU32(state));
}

uint32_t TypePushConstantElementPointer(EmitterState& state) {
	return TypePointer(state, spv::StorageClassPushConstant, TypeU32(state));
}

uint32_t TypeU32ArrayPointer(EmitterState& state, spv::StorageClass storage_class,
                             uint32_t dwords) {
	const auto count = ConstantU32(state, std::max(dwords, 1u));
	const auto array = state.builder.Type(spv::OpTypeArray, TypeU32(state), count);
	return TypePointer(state, storage_class, array);
}

uint32_t TypeU32ElementPointer(EmitterState& state, spv::StorageClass storage_class) {
	return TypePointer(state, storage_class, TypeU32(state));
}

namespace {

uint32_t PushConstantArrayType(EmitterState& state) {
	const auto count = ConstantU32(state, IR::PushData::DwordCount);
	return state.builder.DecoratedType(
	    spv::OpTypeArray, {{spv::OpDecorate, {spv::DecorationArrayStride, sizeof(uint32_t)}}},
	    TypeU32(state), count);
}

uint32_t PushConstantBlockType(EmitterState& state) {
	return state.builder.DecoratedType(spv::OpTypeStruct,
	                                   {{spv::OpMemberDecorate, {0, spv::DecorationOffset, 0}},
	                                    {spv::OpDecorate, {spv::DecorationBlock}}},
	                                   PushConstantArrayType(state));
}

uint32_t PerVertexType(EmitterState& state) {
	return state.builder.DecoratedType(
	    spv::OpTypeStruct,
	    {{spv::OpMemberDecorate, {0, spv::DecorationBuiltIn, spv::BuiltInPosition}},
	     {spv::OpDecorate, {spv::DecorationBlock}}},
	    TypeF32Vector(state, 4));
}

uint32_t SampleMaskArrayType(EmitterState& state) {
	return state.builder.Type(spv::OpTypeArray, TypeI32(state), ConstantU32(state, 1));
}

uint32_t F32ArrayType(EmitterState& state, uint32_t count) {
	return state.builder.Type(spv::OpTypeArray, TypeF32(state), ConstantU32(state, count));
}

void DefineImageArray(EmitterState& state, ImageDefinition& definition, const IR::ImageResource& image,
                      uint32_t count, uint32_t set, uint32_t binding) {
	definition.type     = ImageType(state, image);
	const auto array    = state.builder.Type(spv::OpTypeArray, definition.type, ConstantU32(state, count));
	definition.variable = state.builder.DefineGlobalVariable(
	    TypePointer(state, spv::StorageClassUniformConstant, array), spv::StorageClassUniformConstant);
	state.builder.AddAnnotation(spv::OpDecorate, definition.variable, spv::DecorationDescriptorSet, set);
	state.builder.AddAnnotation(spv::OpDecorate, definition.variable, spv::DecorationBinding, binding);
	definition.pointer_type = TypePointer(state, spv::StorageClassUniformConstant, definition.type);
}

void DefineDescriptors(EmitterState& state) {
	using Kind = IR::DescriptorBindingKind;
	auto& info = state.program.info;
	auto& bindings = state.program.bindings;
	auto& counts = bindings.descriptor_counts;
	auto& buffer_count = counts[static_cast<size_t>(Kind::Buffers)];
	for (auto& buffer: info.buffers) {
		buffer.descriptor_index = buffer.live ? buffer_count++ : UINT32_MAX;
	}
	std::array<const IR::ImageResource*, IR::ImageBindingCount> image_types {};
	for (auto& image: info.images) {
		const auto kind = IR::DescriptorBindingForImage(image);
		if (!kind.has_value() || image.mip_count == 0u ||
		    (image.mip_mode != IR::ImageMipMode::Dynamic && image.mip_count != 1u)) {
			EXIT("shader image has an invalid descriptor type or mip count");
		}
		if (image.heap) {
			// Heap kinds alias one array; the root itself is never accessed.
			auto& definition = state.heap_images[IR::ImageBindingIndex(*kind)];
			if (image.indirect_resources.empty() && definition.variable == 0) {
				DefineImageArray(state, definition, image, IR::ImageHeapCapacity, IR::ImageHeapSet, 0u);
			}
			continue;
		}
		auto& count = counts[static_cast<size_t>(*kind)];
		image.descriptor_index = count;
		if (count == 0) image_types[IR::ImageBindingIndex(*kind)] = &image;
		count += image.mip_count;
	}
	counts[static_cast<size_t>(Kind::Samplers)] = static_cast<uint32_t>(info.samplers.size());
	counts[static_cast<size_t>(Kind::Gds)] = info.uses_gds;
	counts[static_cast<size_t>(Kind::SharedMemory)] =
	    info.uses_lds && state.lds_storage_class == spv::StorageClassStorageBuffer;
	counts[static_cast<size_t>(Kind::BdaPagetable)] = info.uses_dma;
	counts[static_cast<size_t>(Kind::FaultBuffer)] = info.uses_dma;
	counts[static_cast<size_t>(Kind::FlattenedSrt)] = info.uses_flattened_srt;
	bindings.memory_offset_dword = static_cast<uint32_t>(info.user_data_registers.size());
	if (info.uses_dispatch_threads) {
		bindings.dispatch_thread_dword = bindings.memory_offset_dword;
		bindings.memory_offset_dword += 3u;
	}
	bindings.push_data_start_dword =
	    IR::PushData::StartFor(bindings.push_data_start_dword, bindings.ShaderDataDwords());
	counts[static_cast<size_t>(Kind::ShaderData)] =
	    bindings.ShaderDataDwords() != 0 && !bindings.UsesPushData();
	if (state.program.bindings.UsesPushData() || state.program.stage == ShaderType::Mesh ||
	    state.object_primitive_id_variable != 0 || state.user_clip_planes != 0) {
		const auto type              = PushConstantBlockType(state);
		state.push_constant_variable = state.builder.DefineGlobalVariable(
		    TypePointer(state, spv::StorageClassPushConstant, type), spv::StorageClassPushConstant);
		state.builder.AddName(type, "BufferResource");
		state.builder.AddName(state.push_constant_variable, "vsharp");
	}
	for (uint32_t index = 0; index < counts.size(); ++index) {
		if (counts[index] == 0) continue;
		bindings.descriptor_mask |= uint64_t{1} << index;
		const auto kind = static_cast<Kind>(index);
		const auto Define = [&](uint32_t type, const char* name,
		                        spv::StorageClass storage = spv::StorageClassStorageBuffer) {
			const auto variable =
			    state.builder.DefineGlobalVariable(TypePointer(state, storage, type), storage);
			state.builder.AddName(variable, name);
			state.builder.AddAnnotation(spv::OpDecorate, variable, spv::DecorationDescriptorSet, 0);
			state.builder.AddAnnotation(spv::OpDecorate, variable, spv::DecorationBinding,
			                            IR::NativeBinding(state.program.stage, kind));
			return variable;
		};
		const auto ArrayType = [&](uint32_t type) {
			return state.builder.Type(
			    spv::OpTypeArray, type,
			    ConstantU32(state, counts[index]));
		};
		switch (kind) {
			case IR::DescriptorBindingKind::Buffers: {
				const std::array used {info.buffer_u8, info.buffer_u16, true, info.buffer_int64_atomics};
				constexpr std::array names {"buffers_u8", "buffers_u16", "buffers", "buffers_u64"};
				for (uint32_t alias = 0; alias < used.size(); ++alias) {
					if (!used[alias]) continue;
					auto& buffer = state.storage_buffers[alias];
					const auto type = StorageBufferType(state, buffer, 8u << alias);
					buffer.variable = Define(ArrayType(type), names[alias]);
					if (info.buffer_u8 || info.buffer_u16 || info.buffer_int64_atomics) {
						state.builder.AddAnnotation(spv::OpDecorate, buffer.variable, spv::DecorationAliased);
					}
					// RDNA2 stores publish to L2 even without GLC; every alias of the buffer
					// must participate in visibility for cache-bypassing polling loads.
					if (info.coherent_buffers) {
						state.builder.AddAnnotation(spv::OpDecorate, buffer.variable, spv::DecorationCoherent);
					}
				}
				break;
			}
			case IR::DescriptorBindingKind::BdaPagetable:
				state.bda_pagetable_variable =
				    Define(StorageBufferType(state, state.storage_buffers[3], 64), "bda_pagetable");
				break;
			case IR::DescriptorBindingKind::FaultBuffer:
				state.fault_buffer_variable =
				    Define(StorageBufferType(state, state.storage_buffers[2]), "fault_buffer");
				break;
			case IR::DescriptorBindingKind::ShaderData:
				state.shader_data_storage_variable =
				    Define(StorageBufferType(state, state.storage_buffers[2]), "shader_data");
				break;
			case IR::DescriptorBindingKind::FlattenedSrt:
				state.flattened_srt_variable =
				    Define(StorageBufferType(state, state.storage_buffers[2]), "flattened_srt");
				break;
			case IR::DescriptorBindingKind::Samplers:
				state.sampler_type = state.builder.Type(spv::OpTypeSampler);
				state.sampler_pointer_type = TypePointer(
				    state, spv::StorageClassUniformConstant, state.sampler_type);
				state.sampler_variable = Define(ArrayType(state.sampler_type), "samplers",
				                                spv::StorageClassUniformConstant);
				break;
			case IR::DescriptorBindingKind::Gds:
				state.gds_variable = Define(StorageBufferType(state, state.storage_buffers[2]), "gds");
				break;
			case IR::DescriptorBindingKind::SharedMemory:
				state.lds_variable = Define(StorageBufferType(state, state.storage_buffers[2]), "lds_dwords");
				state.builder.AddAnnotation(spv::OpDecorate, state.lds_variable, spv::DecorationCoherent);
				if (state.program.info.shared_int64_atomics) {
					state.lds_u64_variable =
					    Define(StorageBufferType(state, state.storage_buffers[3], 64), "lds_qwords");
					state.builder.AddAnnotation(spv::OpDecorate, state.lds_u64_variable, spv::DecorationCoherent);
					for (const auto variable: {state.lds_variable, state.lds_u64_variable}) {
						state.builder.AddAnnotation(spv::OpDecorate, variable, spv::DecorationAliased);
					}
				}
				break;
			default: {
				EXIT_IF(IR::ImageBindingResourceClass(kind) ==
				        IR::ImageResourceClass::None);
				auto& definition = state.images[IR::ImageBindingIndex(kind)];
				DefineImageArray(state, definition, *image_types[IR::ImageBindingIndex(kind)],
				                 counts[index], 0u, IR::NativeBinding(state.program.stage, kind));
				state.builder.AddName(definition.variable,
				                      ("image_" + std::to_string(static_cast<uint32_t>(kind))).c_str());
				break;
			}
		}
	}
}

} // namespace

uint32_t ConstantU32(EmitterState& state, uint32_t value) {
	return state.builder.Constant(spv::OpConstant, TypeU32(state), value);
}

uint32_t ConstantI32(EmitterState& state, int32_t value) {
	return state.builder.Constant(spv::OpConstant, TypeI32(state), static_cast<uint32_t>(value));
}

uint32_t ConstantF32(EmitterState& state, uint32_t bits) {
	return state.builder.Constant(spv::OpConstant, TypeF32(state), bits);
}

uint32_t ConstantF32Value(EmitterState& state, float value) {
	return ConstantF32(state, std::bit_cast<uint32_t>(value));
}

uint32_t ConstantBool(EmitterState& state, bool value) {
	return state.builder.Constant(value ? spv::OpConstantTrue : spv::OpConstantFalse,
	                              TypeBool(state));
}

uint32_t ConstantU64(EmitterState& state, uint64_t value) {
	return state.builder.Constant(spv::OpConstant, TypeU64(state), static_cast<uint32_t>(value),
	                              static_cast<uint32_t>(value >> 32u));
}

uint32_t ConstantU32CompositeZero(EmitterState& state, uint32_t components) {
	EXIT_IF(components < 1u || components > 4u);
	const auto zero = ConstantU32(state, 0);
	if (components == 1u) return zero;
	const std::array values {zero, zero, zero, zero};
	return state.builder.Constant(spv::OpConstantComposite, TypeU32Composite(state, components),
	                              std::span(values).first(components));
}

uint32_t GlslStd450(EmitterState& state) {
	return state.builder.Import("GLSL.std.450");
}

VertexInputScalarKind VertexParameterScalarKind(const EmitterState& state, uint32_t location) {
	if ((state.program.stage != ShaderType::Vertex && state.program.stage != ShaderType::Local) ||
	    location >= ShaderVertexInputInfo::RES_MAX ||
	    location >= static_cast<uint32_t>(state.input_info.vertex->resources_num)) {
		return VertexInputScalarKind::Float;
	}

	switch (state.input_info.vertex->resources[location].Format()) {
		case Prospero::BufferFormat::k8UInt:
		case Prospero::BufferFormat::k16UInt:
		case Prospero::BufferFormat::k8_8UInt:
		case Prospero::BufferFormat::k32UInt:
		case Prospero::BufferFormat::k16_16UInt:
		case Prospero::BufferFormat::k8_8_8_8UInt:
		case Prospero::BufferFormat::k32_32UInt:
		case Prospero::BufferFormat::k16_16_16_16UInt:
		case Prospero::BufferFormat::k32_32_32UInt:
		case Prospero::BufferFormat::k32_32_32_32UInt: return VertexInputScalarKind::Uint;
		case Prospero::BufferFormat::k8SInt:
		case Prospero::BufferFormat::k16SInt:
		case Prospero::BufferFormat::k8_8SInt:
		case Prospero::BufferFormat::k32SInt:
		case Prospero::BufferFormat::k16_16SInt:
		case Prospero::BufferFormat::k8_8_8_8SInt:
		case Prospero::BufferFormat::k32_32SInt:
		case Prospero::BufferFormat::k16_16_16_16SInt:
		case Prospero::BufferFormat::k32_32_32SInt:
		case Prospero::BufferFormat::k32_32_32_32SInt: return VertexInputScalarKind::Sint;
		default: return VertexInputScalarKind::Float;
	}
}

uint32_t VertexParameterComponentCount(const InputBinding& input) {
	return std::clamp(input.component_count, 1u, 4u);
}

uint32_t VertexParameterScalarType(EmitterState& state, VertexInputScalarKind kind) {
	switch (kind) {
		case VertexInputScalarKind::Sint: return TypeI32(state);
		case VertexInputScalarKind::Uint: return TypeU32(state);
		case VertexInputScalarKind::Float:
		default: return TypeF32(state);
	}
}

uint32_t DefineInterfaceVariable(EmitterState& state, uint32_t type, spv::StorageClass storage,
                                 const char* name) {
	const auto variable =
	    state.builder.DefineGlobalVariable(TypePointer(state, storage, type), storage);
	state.interface_variables.push_back(variable);
	state.builder.AddName(variable, name);
	return variable;
}

namespace {

uint32_t BuiltInForInput(IR::StageInputKind kind) {
	switch (kind) {
		case IR::StageInputKind::VertexIndex: return spv::BuiltInVertexIndex;
		case IR::StageInputKind::InvocationId: return spv::BuiltInInvocationId;
		case IR::StageInputKind::PrimitiveId: return spv::BuiltInPrimitiveId;
		case IR::StageInputKind::TessCoord: return spv::BuiltInTessCoord;
		case IR::StageInputKind::InstanceIndex: return spv::BuiltInInstanceIndex;
		case IR::StageInputKind::FragCoord: return spv::BuiltInFragCoord;
		case IR::StageInputKind::FrontFacing: return spv::BuiltInFrontFacing;
		case IR::StageInputKind::Layer: return spv::BuiltInLayer;
		case IR::StageInputKind::SampleId: return spv::BuiltInSampleId;
		case IR::StageInputKind::BaryCoordSmooth: return spv::BuiltInBaryCoordKHR;
		case IR::StageInputKind::BaryCoordNoPerspective: return spv::BuiltInBaryCoordNoPerspKHR;
		case IR::StageInputKind::WorkgroupId: return spv::BuiltInWorkgroupId;
		case IR::StageInputKind::NumWorkgroups: return spv::BuiltInNumWorkgroups;
		case IR::StageInputKind::LocalInvocationId: return spv::BuiltInLocalInvocationId;
		case IR::StageInputKind::LocalInvocationIndex: return spv::BuiltInLocalInvocationIndex;
		case IR::StageInputKind::GlobalInvocationId: return spv::BuiltInGlobalInvocationId;
		default: return UINT32_MAX;
	}
}

void DefineInputs(EmitterState& state) {
	state.inputs.reserve(state.program.info.inputs.size());
	for (const auto& input: state.program.info.inputs) {
		state.inputs.push_back({input});
	}
	const auto add_builtin = [&](IR::StageInputKind kind, uint32_t components,
	                             const char* name) {
		if (std::ranges::none_of(state.inputs, [kind](const InputBinding& input) {
			    return input.kind == kind;
		    })) {
			state.inputs.push_back({{kind, 0, components, name}});
		}
	};
	if (state.program.info.uses_lds && state.lds_storage_class == spv::StorageClassStorageBuffer) {
		add_builtin(IR::StageInputKind::WorkgroupId, 3, "gl_WorkGroupID");
		add_builtin(IR::StageInputKind::NumWorkgroups, 3, "gl_NumWorkGroups");
	}
	if (state.lane_count == 2) {
		add_builtin(IR::StageInputKind::LocalInvocationIndex, 1, "gl_LocalInvocationIndex");
		if (std::ranges::any_of(state.inputs, [](const InputBinding& input) {
			    return input.kind == IR::StageInputKind::GlobalInvocationId;
		    })) {
			add_builtin(IR::StageInputKind::WorkgroupId, 3, "gl_WorkGroupID");
		}
	}
	for (auto& input: state.inputs) {
		if (state.program.stage == ShaderType::Pixel &&
		    input.kind == IR::StageInputKind::Parameter) {
			const auto location = PixelParameterLocation(state, input.location);
			const auto alias = std::ranges::find_if(state.inputs, [&](const InputBinding& other) {
				return other.kind == IR::StageInputKind::Parameter && other.variable_id != 0 &&
				       PixelParameterLocation(state, other.location) == location;
			});
			if (alias != state.inputs.end()) {
				EXIT_IF(alias->per_vertex != input.per_vertex);
				input.variable_id = alias->variable_id;
				continue;
			}
		}
		uint32_t type = TypeU32(state);
		switch (input.kind) {
			case IR::StageInputKind::VertexIndex:
			case IR::StageInputKind::InvocationId:
			case IR::StageInputKind::PrimitiveId:
			case IR::StageInputKind::InstanceIndex:
			case IR::StageInputKind::Layer:
			case IR::StageInputKind::SampleId: type = TypeI32(state); break;
			case IR::StageInputKind::WorkgroupId:
			case IR::StageInputKind::NumWorkgroups:
			case IR::StageInputKind::LocalInvocationId:
			case IR::StageInputKind::GlobalInvocationId: type = TypeU32Vector(state, 3); break;
			case IR::StageInputKind::FragCoord: type = TypeF32Vector(state, 4); break;
			case IR::StageInputKind::TessCoord:
			case IR::StageInputKind::BaryCoordSmooth:
			case IR::StageInputKind::BaryCoordNoPerspective: type = TypeF32Vector(state, 3); break;
			case IR::StageInputKind::FrontFacing: type = TypeBool(state); break;
			case IR::StageInputKind::Parameter:
				if (state.program.stage == ShaderType::Vertex ||
				    state.program.stage == ShaderType::Local) {
					type = VertexParameterScalarType(
					    state, VertexParameterScalarKind(state, input.location));
					const auto components = VertexParameterComponentCount(input);
					if (components > 1u) {
						type = state.builder.Type(spv::OpTypeVector, type, components);
					}
				} else if (input.per_vertex) {
					type = state.builder.Type(spv::OpTypeArray, TypeF32Vector(state, 4),
					                          ConstantU32(state, 3));
				} else {
					type = TypeF32Vector(state, 4);
				}
				break;
			default: break;
		}
		input.variable_id =
		    DefineInterfaceVariable(state, type, spv::StorageClassInput, input.debug_name.c_str());
		if (state.program.stage == ShaderType::Pixel && input.kind == IR::StageInputKind::PrimitiveId) {
			// Fragment PrimitiveId accepts Tessellation, which the device already enables.
			state.builder.RequireCapability(spv::CapabilityTessellation);
			state.builder.AddAnnotation(spv::OpDecorate, input.variable_id, spv::DecorationFlat);
		}
		if (input.kind == IR::StageInputKind::Layer || input.kind == IR::StageInputKind::SampleId) {
			state.builder.AddAnnotation(spv::OpDecorate, input.variable_id, spv::DecorationFlat);
		}
		if (input.kind == IR::StageInputKind::Parameter) {
			const auto flat = PixelParameterIsFlat(state, input.location);
			if (input.per_vertex) {
				state.builder.AddAnnotation(spv::OpDecorate, input.variable_id,
				                            spv::DecorationPerVertexKHR);
			} else if (flat) {
				state.builder.AddAnnotation(spv::OpDecorate, input.variable_id,
				                            spv::DecorationFlat);
			}
			if (state.program.stage == ShaderType::Pixel &&
			    state.input_info.pixel->ps_no_perspective && !flat && !input.per_vertex) {
				state.builder.AddAnnotation(spv::OpDecorate, input.variable_id,
				                            spv::DecorationNoPerspective);
			}
			state.builder.AddAnnotation(spv::OpDecorate, input.variable_id, spv::DecorationLocation,
			                            PixelParameterLocation(state, input.location));
		} else if (const auto builtin = BuiltInForInput(input.kind); builtin != UINT32_MAX) {
			state.builder.AddAnnotation(spv::OpDecorate, input.variable_id, spv::DecorationBuiltIn,
			                            builtin);
		}
	}
	if (state.program.info.subgroup_local_invocation_id) {
		const auto variable = DefineInterfaceVariable(state, TypeU32(state), spv::StorageClassInput,
		                                              "gl_SubgroupInvocationID");
		state.subgroup_local_invocation_id_variable = variable;
		state.builder.AddAnnotation(spv::OpDecorate, variable, spv::DecorationBuiltIn,
		                            spv::BuiltInSubgroupLocalInvocationId);
		if (state.program.stage == ShaderType::Pixel) {
			state.builder.AddAnnotation(spv::OpDecorate, variable, spv::DecorationFlat);
		}
	}
}

void DefineOutputs(EmitterState& state) {
	state.outputs.reserve(state.program.info.outputs.size());
	uint32_t clip_distance_count = 0;
	uint32_t cull_distance_count = 0;
	for (const auto& output: state.program.info.outputs) {
		state.outputs.push_back({output});
		if (output.kind == IR::StageOutputKind::ClipDistance) {
			clip_distance_count = std::max(clip_distance_count, output.index + 1);
		} else if (output.kind == IR::StageOutputKind::CullDistance) {
			cull_distance_count = std::max(cull_distance_count, output.index + 1);
		}
	}
	const bool position = std::ranges::any_of(state.outputs, [](const OutputBinding& output) {
		return output.kind == IR::StageOutputKind::Position;
	});
	if (position && state.input_info.vertex->user_clip_planes != 0) {
		// PipelineCache rejects UCP_ENA with shader clip or cull distances.
		EXIT_IF(clip_distance_count + cull_distance_count != 0);
		state.user_clip_planes = state.input_info.vertex->user_clip_planes;
		for (auto mask = state.user_clip_planes; mask != 0; mask &= mask - 1u) {
			state.outputs.push_back(
			    {{IR::StageOutputKind::ClipDistance, clip_distance_count++, 0, "gl_ClipDistance"}});
		}
	}
	if (state.program.stage == ShaderType::Mesh) {
		DefineMeshOutputs(state, clip_distance_count, cull_distance_count);
		return;
	}
	if (state.program.stage == ShaderType::Vertex &&
	    clip_distance_count + cull_distance_count < 8u && position) {
		// Reserve one plane for the enabled PA_CL_CLIP_CNTL clipping-error cull.
		state.invalid_position_clip_distance = clip_distance_count++;
		state.outputs.push_back({{IR::StageOutputKind::ClipDistance,
		                          state.invalid_position_clip_distance, 0, "gl_ClipDistance"}});
	}
	const auto BuiltIn = [&](uint32_t& variable, uint32_t type, const char* name,
	                         spv::BuiltIn builtin) {
		if (variable == 0) {
			variable = DefineInterfaceVariable(state, type, spv::StorageClassOutput, name);
			state.builder.AddAnnotation(spv::OpDecorate, variable, spv::DecorationBuiltIn, builtin);
		}
		return variable;
	};
	for (auto& binding: state.outputs) {
		switch (binding.kind) {
			case IR::StageOutputKind::Position:
				if (state.per_vertex_variable == 0) {
					const auto type = PerVertexType(state);
					state.builder.AddName(type, "gl_PerVertex");
					state.per_vertex_variable = DefineInterfaceVariable(
					    state, type, spv::StorageClassOutput, "outPerVertex");
				}
				binding.variable_id = state.per_vertex_variable;
				break;
			case IR::StageOutputKind::PointSize:
				binding.variable_id = BuiltIn(state.point_size_variable, TypeF32(state),
				                              "gl_PointSize", spv::BuiltInPointSize);
				break;
			case IR::StageOutputKind::ClipDistance:
				binding.variable_id =
				    BuiltIn(state.clip_distance_variable, F32ArrayType(state, clip_distance_count),
				            "gl_ClipDistance", spv::BuiltInClipDistance);
				break;
			case IR::StageOutputKind::CullDistance:
				binding.variable_id =
				    BuiltIn(state.cull_distance_variable, F32ArrayType(state, cull_distance_count),
				            "gl_CullDistance", spv::BuiltInCullDistance);
				break;
			case IR::StageOutputKind::Layer:
				binding.variable_id =
				    BuiltIn(state.layer_variable, TypeU32(state), "gl_Layer", spv::BuiltInLayer);
				break;
			case IR::StageOutputKind::ViewportIndex:
				binding.variable_id = BuiltIn(state.viewport_index_variable, TypeU32(state),
				                              "gl_ViewportIndex", spv::BuiltInViewportIndex);
				break;
			case IR::StageOutputKind::Depth:
				binding.variable_id = BuiltIn(state.depth_variable, TypeF32(state), "gl_FragDepth",
				                              spv::BuiltInFragDepth);
				break;
			case IR::StageOutputKind::SampleMask:
				binding.variable_id =
				    BuiltIn(state.sample_mask_variable, SampleMaskArrayType(state), "gl_SampleMask",
				            spv::BuiltInSampleMask);
				break;
			case IR::StageOutputKind::ObjectPrimitiveId:
				binding.variable_id = DefineInterfaceVariable(
				    state, TypeU32(state), spv::StorageClassOutput, binding.debug_name.c_str());
				state.object_primitive_id_variable = binding.variable_id;
				state.builder.AddAnnotation(spv::OpDecorate, binding.variable_id,
				                            spv::DecorationLocation, binding.location);
				break;
			case IR::StageOutputKind::Parameter:
			case IR::StageOutputKind::Mrt: {
				const bool uint_output =
				    binding.kind == IR::StageOutputKind::Mrt &&
				    state.program.stage == ShaderType::Pixel &&
				    binding.index < std::size(state.input_info.pixel->target_output_mode) &&
				    (state.input_info.pixel->target_output_mode[binding.index] == 7u ||
				     (state.input_info.pixel->target_packed_unorm_mask & (1u << binding.index)) != 0u);
				const auto type = uint_output ? TypeU32Vector(state, 4) : TypeF32Vector(state, 4);
				binding.variable_id = DefineInterfaceVariable(state, type, spv::StorageClassOutput,
				                                              binding.debug_name.c_str());
				const bool dual_source = binding.kind == IR::StageOutputKind::Mrt &&
				                         state.program.stage == ShaderType::Pixel &&
				                         state.input_info.pixel->dual_source_blending;
				EXIT_NOT_IMPLEMENTED(dual_source && binding.index > 1);
				state.builder.AddAnnotation(spv::OpDecorate, binding.variable_id,
				                            spv::DecorationLocation,
				                            dual_source ? 0u : binding.location);
				if (dual_source) {
					state.builder.AddAnnotation(spv::OpDecorate, binding.variable_id,
					                            spv::DecorationIndex, binding.index);
				}
				break;
			}
		}
	}
}

} // namespace

void DefineModule(EmitterState& state) {
	state.interface_variables.reserve(state.program.info.inputs.size() +
	                                  state.program.info.outputs.size());
	DefineInputs(state);
	DefineOutputs(state);
	DefineTessellationInterfaces(state);
	DefineDescriptors(state);
	if (state.program.info.function_lds) {
		state.lds_variable = state.builder.AllocateId();
	}
	if (state.program.info.function_scratch) {
		for (uint32_t half = 0; half < state.lane_count; half++) {
			state.scratch_variable[half] = state.builder.AllocateId();
		}
	}
	state.main_func = state.builder.AllocateId();
	if (state.program.stage == ShaderType::Mesh) {
		state.mesh_guest_func = state.builder.AllocateId();
		state.builder.RequireCapability(spv::CapabilityMeshShadingEXT); // MeshShadingEXT
		state.builder.RequireExtension("SPV_EXT_mesh_shader");
		state.builder.AddExecutionMode(state.main_func,
		                               spv::ExecutionModeOutputTrianglesEXT); // OutputTrianglesEXT
		state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeOutputVertices,
		                               state.input_info.vertex->mesh.max_vertices);
		state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeOutputPrimitivesEXT,
		                               state.input_info.vertex->mesh.max_primitives);
	}
	if (state.program.stage == ShaderType::TessellationControl ||
	    state.program.stage == ShaderType::TessellationEvaluation) {
		DefineTessellationExecutionModes(state);
	}
	state.entry_label = state.builder.AllocateId();

	state.builder.RequireCapability(spv::CapabilityShader);
	state.builder.RequireCapability(spv::CapabilitySignedZeroInfNanPreserve);
	if (state.program.info.buffer_u8) {
		state.builder.RequireExtension("SPV_KHR_8bit_storage");
		state.builder.RequireCapability(spv::CapabilityStorageBuffer8BitAccess);
	}
	if (state.program.info.buffer_u16) {
		state.builder.RequireCapability(spv::CapabilityStorageBuffer16BitAccess);
	}
	if (state.program.info.uses_dma || state.program.info.uses_image_heap) {
		state.builder.RequireCapability(spv::CapabilityInt64);
		state.builder.RequireCapability(spv::CapabilityPhysicalStorageBufferAddresses);
		state.builder.RequireExtension("SPV_KHR_physical_storage_buffer");
	}
	if (state.program.info.buffer_int64_atomics || state.program.info.shared_int64_atomics) {
		state.builder.RequireCapability(spv::CapabilityInt64);
		state.builder.RequireCapability(spv::CapabilityInt64Atomics);
	}
	if (state.program.info.shared_int64_atomics &&
	    state.lds_storage_class == spv::StorageClassWorkgroup) {
		state.builder.RequireVersion(0x00010400u);
		state.builder.RequireExtension("SPV_KHR_workgroup_memory_explicit_layout");
		state.builder.RequireCapability(spv::CapabilityWorkgroupMemoryExplicitLayoutKHR);
	}
	if (state.clip_distance_variable != 0) {
		state.builder.RequireCapability(spv::CapabilityClipDistance);
	}
	if (state.cull_distance_variable != 0) {
		state.builder.RequireCapability(spv::CapabilityCullDistance);
	}
	if (state.layer_variable != 0 || InputVariableForKind(state, IR::StageInputKind::Layer) != 0) {
		state.builder.RequireVersion(0x00010500u);
		state.builder.RequireCapability(spv::CapabilityShaderLayer);
	}
	if (state.viewport_index_variable != 0) {
		state.builder.RequireVersion(0x00010500u);
		state.builder.RequireCapability(spv::CapabilityShaderViewportIndex);
	}
	if (InputVariableForKind(state, IR::StageInputKind::SampleId) != 0) {
		state.builder.RequireCapability(spv::CapabilitySampleRateShading);
	}
	if (state.program.info.image_gather_extended) {
		state.builder.RequireCapability(spv::CapabilityImageGatherExtended);
	}
	if (state.lane_count == 2 || state.program.info.subgroup_barrier ||
	    state.program.info.subgroup_ballot || state.program.info.subgroup_vote ||
	    state.program.info.subgroup_shuffle ||
	    state.program.info.subgroup_arithmetic || state.program.info.subgroup_local_invocation_id) {
		state.builder.RequireCapability(spv::CapabilityGroupNonUniform);
	}
	if (state.lane_count == 2 || state.program.info.subgroup_ballot) {
		state.builder.RequireCapability(spv::CapabilityGroupNonUniformBallot);
	}
	if (state.program.info.subgroup_vote) {
		state.builder.RequireCapability(spv::CapabilityGroupNonUniformVote);
	}
	if (state.program.info.subgroup_shuffle) {
		state.builder.RequireCapability(spv::CapabilityGroupNonUniformShuffle);
	}
	if (state.program.info.subgroup_arithmetic) {
		state.builder.RequireCapability(spv::CapabilityGroupNonUniformArithmetic);
	}
	if (state.program.info.compute_derivatives && state.program.stage == ShaderType::Compute) {
		state.builder.RequireCapability(spv::CapabilityComputeDerivativeGroupQuadsKHR);
		state.builder.RequireExtension("SPV_KHR_compute_shader_derivatives");
	}
	const bool fragment_barycentric =
	    state.program.stage == ShaderType::Pixel &&
	    std::any_of(state.inputs.begin(), state.inputs.end(), [](const InputBinding& input) {
		    return input.per_vertex || input.kind == IR::StageInputKind::BaryCoordSmooth ||
		           input.kind == IR::StageInputKind::BaryCoordNoPerspective;
	    });
	if (fragment_barycentric) {
		state.builder.RequireCapability(spv::CapabilityFragmentBarycentricKHR);
		state.builder.RequireExtension("SPV_KHR_fragment_shader_barycentric");
	}
	state.builder.RequireExtension("SPV_KHR_float_controls");
	state.builder.AddMemoryModel(state.program.info.uses_dma || state.program.info.uses_image_heap
	                                 ? spv::AddressingModelPhysicalStorageBuffer64
	                                 : spv::AddressingModelLogical,
	                             spv::MemoryModelGLSL450);
	// GCN/RDNA arithmetic preserves 32-bit signed zero, infinity, and NaN. Declaring that
	// contract prevents host compilers from treating synthesized IEEE values as finite.
	state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeSignedZeroInfNanPreserve,
	                               32u);
	if (state.program.info.float64) {
		EXIT_NOT_IMPLEMENTED(state.program.stage == ShaderType::Compute &&
		                     state.input_info.compute->float_mode != 0xc0);
		// Use native rounding for MODE=0xc0, consistent with ordinary FP32 arithmetic.
		state.builder.RequireCapability(spv::CapabilityFloat64);
		state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeSignedZeroInfNanPreserve,
		                               64u);
		// FP64 denormal preservation is temporarily disabled.
		// state.builder.RequireCapability(spv::CapabilityDenormPreserve);
		// state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeDenormPreserve, 64u);
	}
	if (const auto* cs = ShaderWorkgroupInput(state.program.stage, state.input_info)) {
		uint32_t    local_x = state.program.info.compute_derivatives ? 2u : 1u;
		uint32_t    local_y = state.program.info.compute_derivatives ? 2u : 1u;
		uint32_t    local_z = 1u;
		local_x             = cs->threads_num[0] != 0u ? cs->threads_num[0] : local_x;
		local_y             = cs->threads_num[1] != 0u ? cs->threads_num[1] : local_y;
		local_z             = cs->threads_num[2] != 0u ? cs->threads_num[2] : local_z;
		if (state.lane_count == 2) {
			local_x = ((local_x * local_y * local_z + 63u) / 64u) * 32u;
			local_y = local_z = 1u;
			if (state.program.info.compute_derivatives) {
				local_y = local_x / 2u;
				local_x = 2u;
			}
		}
		state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeLocalSize, local_x,
		                               local_y, local_z);
	}
	if (state.program.stage == ShaderType::Pixel) {
		state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeOriginUpperLeft);
		if (state.depth_variable != 0) {
			state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeDepthReplacing);
		}
		if (state.input_info.pixel->ps_early_z && !state.input_info.pixel->ps_pixel_kill_enable &&
		    !state.input_info.pixel->ps_depth_export_enable &&
		    !state.input_info.pixel->ps_sample_mask_export_enable) {
			state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeEarlyFragmentTests);
		}
	}
	if (state.program.info.compute_derivatives && state.program.stage == ShaderType::Compute) {
		state.builder.AddExecutionMode(state.main_func, spv::ExecutionModeDerivativeGroupQuadsKHR);
	}
	state.builder.AddName(state.main_func, "main");
	if (state.program.info.function_lds) {
		state.builder.AddName(state.lds_variable, "lds_dwords");
	}
	if (state.program.info.function_scratch) {
		for (uint32_t half = 0; half < state.lane_count; half++) {
			state.builder.AddName(state.scratch_variable[half], "scratch_dwords");
		}
	}
}

} // namespace Libs::Graphics::ShaderRecompiler::Spirv::Emitter
