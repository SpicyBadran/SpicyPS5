#ifndef CORE_LIBS_PRX_LIBSCEAGCDRIVER_GRAPHICS_INCLUDE_TEXTUREDETILER_HPP
#define CORE_LIBS_PRX_LIBSCEAGCDRIVER_GRAPHICS_INCLUDE_TEXTUREDETILER_HPP

#include <array>
#include "prx/libSceAgcDriver/Graphics/include/Context.hpp"
#include "prx/libSceAgcDriver/Graphics/include/GuestTextureResource.hpp"
#include "prx/libSceAgcDriver/Graphics/include/TextureTiling.hpp"
#include <cstddef>
#include <cstdint>
#include <memory>
#include <utility>
#include <vector>

namespace AgcDriver::Graphics {

    class Buffer;

    // The part of a mip one Dispatch moves: only elements whose tiled offset (relative to the mip's
    // tiled base; the linear offset of a linear surface) lies in [rangeBegin, rangeEnd), with the
    // tiled buffer holding the mip from tiledBase and the linear buffer holding `linearBytes` of
    // it from linearBase (a window of whole rows: linearBase is a row's start, every element in
    // the range lies inside the window; 0 for the rest of the mip). The element rectangle
    // [columnBegin, columnEnd) x [rowBegin, rowEnd) (an end of 0: the mip's edge) bounds the
    // elements the range can hold: only its workgroups are dispatched, the range check stays the
    // guard. The default moves the whole mip out of whole buffers.
    struct DetileWindow {
        std::uint32_t rangeBegin = 0;
        std::uint32_t rangeEnd = 0xffffffffu;
        std::uint32_t tiledBase = 0;
        std::uint32_t linearBase = 0;
        std::uint64_t linearBytes = 0;
        std::uint32_t columnBegin = 0;
        std::uint32_t columnEnd = 0;
        std::uint32_t rowBegin = 0;
        std::uint32_t rowEnd = 0;
        std::uint32_t pipeBankXor = 0;
    };

    class TextureDetiler {
    public:
        explicit TextureDetiler(const Context& context);
        ~TextureDetiler();
        TextureDetiler(const TextureDetiler&) = delete;
        TextureDetiler& operator=(const TextureDetiler&) = delete;

        // Detiles `source` (tiled) into `destination` (linear), or with `retile` writes linear `source`
        // into tiled `destination`; offsets always refer to the respective buffers, and `window`
        // restricts the move to part of the mip (a partial upload or write-back, StorageTexture),
        // leaving the other elements of both buffers alone.
        void Dispatch(VkCommandBuffer commands, TextureTileMode tileMode, std::uint32_t elementBytes, VkBuffer source, std::uint64_t sourceOffset, VkBuffer destination, std::uint64_t destinationOffset, const TileMipLayout& layout, bool retile = false, std::uint32_t slice = 0, bool thick = false, const DetileWindow& window = {});
        void DispatchImage(VkCommandBuffer commands, TextureTileMode tileMode, std::uint32_t elementBytes, VkBuffer tiled, std::uint64_t tiledOffset, VkImageView view, const TileMipLayout& layout, bool retile = false, std::uint32_t slice = 0, const DetileWindow& window = {});
        void DispatchRepack(VkCommandBuffer commands, VkBuffer source, std::uint64_t sourceOffset, VkBuffer destination, std::uint64_t destinationOffset, std::uint64_t bytes);
        static VkFormat ImageElementFormat(std::uint32_t elementBytes);
        // Recycles the descriptor sets of the previous batch; call before recording a new command batch.
        void BeginBatch();
        void DispatchCmaskClear(VkCommandBuffer commands, VkBuffer cmask, std::uint64_t cmaskOffset, std::size_t cmaskBytes, VkImageView view, std::uint32_t width, std::uint32_t height, std::uint32_t elementBytes, const std::array<std::uint32_t, 2>& clearWords, bool write);
        std::uint32_t CmaskErrors();
        void DispatchMultisampleReadback(VkCommandBuffer commands, VkFormat format, VkBuffer destination, std::uint64_t offset, std::uint64_t bytes, VkImageView arrayView, std::uint32_t width, std::uint32_t height, std::uint32_t layers, std::uint32_t fragments, std::uint32_t firstElement, std::uint32_t elements);
        void DispatchDepthSample(VkCommandBuffer commands, VkImageView depth, bool multisampled, VkImageView target, std::uint32_t width, std::uint32_t height, std::uint32_t sample);
        void DispatchMultisampleImage(VkCommandBuffer commands, std::uint32_t elementBytes, VkBuffer source, std::uint64_t offset, std::uint64_t bytes, VkImageView arrayView, std::uint32_t width, std::uint32_t height, std::uint32_t layers, std::uint32_t fragments, std::uint32_t firstElement, std::uint32_t elements);

    private:
        VkPipeline multisampleReadbackPipeline(std::uint32_t elementBytes, bool depth);
        VkPipeline multisampleUploadPipeline(std::uint32_t elementBytes);
        VkPipeline pipeline(TextureTileMode tileMode, std::uint32_t elementBytes, bool retile, bool thick, bool image = false);
        void release() noexcept;
        struct DescriptorRing {
            std::vector<VkDescriptorPool> pools;
            std::vector<std::uint64_t> serials;
            std::size_t current = 0;
            std::uint32_t used = 0;
        };
        VkDescriptorSet allocateSet(bool image = false);
        VkDescriptorSet allocateFrom(DescriptorRing& ring, VkDescriptorSetLayout layout, const std::vector<VkDescriptorPoolSize>& sizes, const char* createWhat, const char* allocateWhat, const char* resetWhat);
        void resetRing(DescriptorRing& ring, const char* resetWhat);
        void checkWindow(const TileMipLayout& layout, const DetileWindow& window, std::uint32_t& columnEnd, std::uint32_t& rowEnd) const;

        const Context context;
        VkDescriptorSetLayout descriptorLayout = VK_NULL_HANDLE;
        VkPipelineLayout pipelineLayout = VK_NULL_HANDLE;
        VkShaderModule module = VK_NULL_HANDLE;
        std::vector<std::pair<std::uint32_t, VkPipeline>> pipelines;
        DescriptorRing descriptorSets;
        VkDescriptorSetLayout cmaskDescriptorLayout = VK_NULL_HANDLE;
        VkPipelineLayout cmaskPipelineLayout = VK_NULL_HANDLE;
        VkPipeline cmaskPipeline = VK_NULL_HANDLE;
        DescriptorRing cmaskDescriptorSets;
        VkDescriptorSetLayout depthSampleLayout = VK_NULL_HANDLE;
        VkPipelineLayout depthSamplePipelineLayout = VK_NULL_HANDLE;
        std::array<VkPipeline, 2> depthSamplePipelines{};
        VkSampler depthSampler = VK_NULL_HANDLE;
        DescriptorRing depthSampleSets;
        std::unique_ptr<Buffer> cmaskErrors;
        VkDescriptorSetLayout imageDescriptorLayout = VK_NULL_HANDLE;
        VkPipelineLayout imagePipelineLayout = VK_NULL_HANDLE;
        VkShaderModule imageModule = VK_NULL_HANDLE;
        VkShaderModule repackModule = VK_NULL_HANDLE;
        VkPipeline repackPipeline = VK_NULL_HANDLE;
        DescriptorRing imageDescriptorSets;
        VkDescriptorSetLayout readbackDescriptorLayout = VK_NULL_HANDLE;
        VkPipelineLayout readbackPipelineLayout = VK_NULL_HANDLE;
        std::array<VkShaderModule, 2> readbackModules{};
        std::vector<std::pair<std::uint32_t, VkPipeline>> readbackPipelines;
        DescriptorRing readbackDescriptorSets;
        VkShaderModule multisampleUploadModule = VK_NULL_HANDLE;
    };

}

#endif
